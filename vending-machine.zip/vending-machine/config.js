// config.js
module.exports = {
    API_KEY: 'supersecure123'
  };
  